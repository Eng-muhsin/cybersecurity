<?php

$host = "localhost";
$db   = "tijaabo";
$user = "root";
$pass = "";

$message = "";

try {

    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

} catch (PDOException $e) {

    die("Database connection failed.");

}


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $compassword = $_POST["compassword"] ?? "";


    // Hubinta fields-ka

    if (
        $username === "" ||
        $email === "" ||
        $password === "" ||
        $compassword === ""
    ) {

        $message = "Fadlan buuxi dhammaan meelaha.";

    }

    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = "Email-ka sax ma aha.";

    }

    elseif ($password !== $compassword) {

        $message = "Password iyo Confirm Password isku mid ma aha.";

    }

    elseif (strlen($password) < 8) {

        $message = "Password-ku waa inuu ugu yaraan 8 xaraf noqdaa.";

    }

    else {

        // Hubi username ama email hore u jiray

        $check = $pdo->prepare(
            "SELECT id
             FROM users
             WHERE username = :username
             OR email = :email
             LIMIT 1"
        );

        $check->execute([
            ":username" => $username,
            ":email" => $email
        ]);

        if ($check->fetch()) {

            $message = "Username ama Email hore ayaa loo isticmaalay.";

        }

        else {

            // Password hash

            $hashedPassword = password_hash(
                $password,
                PASSWORD_DEFAULT
            );


            // Prepared statement

            $stmt = $pdo->prepare(
                "INSERT INTO users
                (username, email, password)
                VALUES
                (:username, :email, :password)"
            );

            $stmt->execute([
                ":username" => $username,
                ":email" => $email,
                ":password" => $hashedPassword
            ]);


            $message = "Register successful! Account-ka waa la sameeyay.";

        }

    }

}

?>

<!DOCTYPE html>

<html lang="so">

<head>

<meta charset="UTF-8">

<title>Secure Register</title>

<style>

body {
    font-family: Arial, sans-serif;
    background: #f2f2f2;
}

.box {
    width: 380px;
    margin: 70px auto;
    padding: 30px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 5px 20px rgba(0,0,0,.15);
}

h2 {
    text-align: center;
}

input {
    width: 100%;
    padding: 12px;
    margin: 8px 0;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    width: 100%;
    padding: 12px;
    margin-top: 10px;
    background: #1677ff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.message {
    margin-top: 15px;
    padding: 12px;
    background: #eee;
    border-radius: 5px;
}

</style>

</head>

<body>

<div class="box">

<h2>Create Account</h2>

<form method="POST">

<input
    type="text"
    name="username"
    placeholder="Username"
    required
>

<input
    type="email"
    name="email"
    placeholder="Email"
    required
>

<input
    type="password"
    name="password"
    placeholder="Password"
    required
>

<input
    type="password"
    name="compassword"
    placeholder="Confirm Password"
    required
>

<button type="submit">
    Register
</button>

</form>


<?php if ($message): ?>

<div class="message">

<?= htmlspecialchars($message) ?>

</div>

<?php endif; ?>


</div>

</body>

</html>