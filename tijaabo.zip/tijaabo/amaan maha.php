<?php

$host = "localhost";
$db   = "tijaabo";
$user = "root";
$pass = "";

$message = "";

$conn = new mysqli(
    $host,
    $user,
    $pass,
    $db
);

if ($conn->connect_error) {

    die("Database connection failed.");

}


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = $_POST["username"] ?? "";
    $email = $_POST["email"] ?? "";
    $password = $_POST["password"] ?? "";
    $compassword = $_POST["compassword"] ?? "";


    if (
        $username === "" ||
        $email === "" ||
        $password === "" ||
        $compassword === ""
    ) {

        $message = "Fadlan buuxi dhammaan meelaha.";

    }

    elseif ($password !== $compassword) {

        $message = "Password iyo Confirm Password isku mid ma aha.";

    }

    else {

        /*
        DIGNIIN:

        Code-kan waa ula kac ahaan aan ammaan ahayn.

        User input si toos ah ayaa loogu dhex darayaa SQL.
        Password-kana plain text ayaa loo kaydinayaa.

        Ku isticmaal localhost oo keliya.
        */


        $sql = "INSERT INTO users
                (username, email, password)
                VALUES
                ('$username', '$email', '$password')";


        if ($conn->query($sql)) {

            $message = "Register successful! Account-ka waa la sameeyay.";

        }

        else {

            $message = "Error: " . $conn->error;

        }

    }

}

?>

<!DOCTYPE html>

<html lang="so">

<head>

<meta charset="UTF-8">

<title>Insecure Register</title>

<style>

body {
    font-family: Arial, sans-serif;
    background: #f2f2f2;
}

.box {
    width: 380px;
    margin: 70px auto;
    padding: 30px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 5px 20px rgba(0,0,0,.15);
}

h2 {
    text-align: center;
}

.warning {
    background: #ffe0e0;
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 5px;
}

input {
    width: 100%;
    padding: 12px;
    margin: 8px 0;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    width: 100%;
    padding: 12px;
    margin-top: 10px;
    background: #d33;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.message {
    margin-top: 15px;
    padding: 12px;
    background: #eee;
    border-radius: 5px;
}

</style>

</head>

<body>

<div class="box">

<h2>Create Account</h2>

<div class="warning">

⚠️ Version-kan waa tijaabo amaana maha.

</div>

<form method="POST">

<input
    type="text"
    name="username"
    placeholder="Username"
    required
>

<input
    type="email"
    name="email"
    placeholder="Email"
    required
>

<input
    type="password"
    name="password"
    placeholder="Password"
    required
>

<input
    type="password"
    name="compassword"
    placeholder="Confirm Password"
    required
>

<button type="submit">
    Register
</button>

</form>


<?php if ($message): ?>

<div class="message">

<?= htmlspecialchars($message) ?>

</div>

<?php endif; ?>


</div>

</body>

</html>